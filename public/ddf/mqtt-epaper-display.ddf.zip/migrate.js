const fs = require("fs")
const path = require("path")

const DIR = __dirname
const svgPath = path.join(DIR, "adornment.svg")
const devicePath = path.join(DIR, "device.json")

const device = JSON.parse(fs.readFileSync(devicePath, "utf8"))
// oldSvgId (e.g. "button-0") -> { newId ("button-10"), name ("Button 10") }
const renameMap = {}
for (const btn of device.hardwareButtons) {
  const newId = btn.id.replace(/^btn-/, "button-")
  renameMap[btn.svgElementId] = { newId, name: btn.name }
}
console.log("Rename map:", renameMap)

let svg = fs.readFileSync(svgPath, "utf8")

// This hand-authored SVG never declared the inkscape: namespace (no
// Inkscape lineage) - add it so inkscape:label below is well-formed XML,
// even though Inkscape itself never touched this file.
if (!svg.includes("xmlns:inkscape=")) {
  svg = svg.replace(
    /<svg xmlns="http:\/\/www\.w3\.org\/2000\/svg"/,
    '<svg xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns="http://www.w3.org/2000/svg"',
  )
}

// Phase 1: old id -> unique placeholder, to avoid collisions during rename
// (e.g. button-0 -> button-10 while some other element is also being
// renamed TO button-0 in this same pass).
for (const oldId of Object.keys(renameMap)) {
  const placeholder = `__TEMP_${oldId}__`
  svg = svg.replace(new RegExp(`id="${oldId}"`), `id="${placeholder}"`)
}
// Phase 2: placeholder -> final new id, adding inkscape:label alongside.
for (const [oldId, { newId, name }] of Object.entries(renameMap)) {
  const placeholder = `__TEMP_${oldId}__`
  svg = svg.replace(new RegExp(`id="${placeholder}"`), `id="${newId}" inkscape:label="${name}"`)
}

fs.writeFileSync(svgPath, svg)
console.log("adornment.svg rewritten")
